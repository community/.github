# SharedWorkerInfo Object

* `id` string - The unique id of the shared worker.
* `url` string - The url of the shared worker.
