# IOCounters Object

* `readOperationCount` number - The number of I/O read operations.
* `writeOperationCount` number - The number of I/O write operations.
* `otherOperationCount` number - Then number of I/O other operations.
* `readTransferCount` number - The number of I/O read transfers.
* `writeTransferCount` number - The number of I/O write transfers.
* `otherTransferCount` number - Then number of I/O other transfers.
