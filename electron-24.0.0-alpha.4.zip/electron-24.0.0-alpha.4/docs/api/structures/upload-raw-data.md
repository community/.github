# UploadRawData Object

* `type` 'rawData' - `rawData`.
* `bytes` Buffer - Data to be uploaded.
