# MemoryUsageDetails Object

* `count` number
* `size` number
* `liveSize` number
