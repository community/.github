# ProtocolRequest Object

* `url` string
* `referrer` string
* `method` string
* `uploadData` [UploadData[]](upload-data.md) (optional)
* `headers` Record<string, string>
