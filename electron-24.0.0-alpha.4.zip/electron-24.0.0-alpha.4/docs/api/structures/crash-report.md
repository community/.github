# CrashReport Object

* `date` Date
* `id` string
