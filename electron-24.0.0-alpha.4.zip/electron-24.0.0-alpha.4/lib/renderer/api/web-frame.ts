const { mainFrame } = process._linkedBinding('electron_renderer_web_frame');

export default mainFrame;
