import { wrapFsWithAsar } from './fs-wrapper';

wrapFsWithAsar(require('fs'));
