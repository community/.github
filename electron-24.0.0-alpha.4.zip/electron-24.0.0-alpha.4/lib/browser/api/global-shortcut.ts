const { globalShortcut } = process._linkedBinding('electron_browser_global_shortcut');
export default globalShortcut;
