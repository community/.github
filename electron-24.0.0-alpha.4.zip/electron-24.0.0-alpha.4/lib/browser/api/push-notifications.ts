const { pushNotifications } = process._linkedBinding('electron_browser_push_notifications');

export default pushNotifications;
