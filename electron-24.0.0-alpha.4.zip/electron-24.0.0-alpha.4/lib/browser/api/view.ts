const { View } = process._linkedBinding('electron_browser_view');

export default View;
