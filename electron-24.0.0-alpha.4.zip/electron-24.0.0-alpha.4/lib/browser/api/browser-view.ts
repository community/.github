const { BrowserView } = process._linkedBinding('electron_browser_browser_view');

export default BrowserView;
