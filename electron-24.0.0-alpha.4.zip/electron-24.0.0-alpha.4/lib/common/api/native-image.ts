const { nativeImage } = process._linkedBinding('electron_common_native_image');

export default nativeImage;
