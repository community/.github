const shell = process._linkedBinding('electron_common_shell');

export default shell;
